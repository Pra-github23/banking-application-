package com.example.banking.controller;

import com.example.banking.entity.Account;
import com.example.banking.service.AccountService;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import java.util.List;



@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;
 
    //Create  account 
    @PostMapping
    public ResponseEntity<Account> createAccount(@RequestBody Account account) {
        Account createdAccount = accountService.createAccount(account);
        return new ResponseEntity<>(createdAccount, HttpStatus.CREATED);
    }

    //get account
    @GetMapping("/getAccount")
    public ResponseEntity<Account> getAccount(@RequestParam Long id) {
        Account getAccount = accountService.getAccount(id);
        if (getAccount == null) {
            // ErrorResponse errorResponse = new ErrorResponse("Account with id " + id + " not found", 404);
            return new ResponseEntity<>(getAccount, HttpStatus.NOT_FOUND);
        } 
         return new ResponseEntity<>(getAccount, HttpStatus.OK);
    }
    
    //update account
    @PutMapping("/updateAccount")
    public ResponseEntity<Account> updateAccount(@RequestBody Account account){
        Account updateAccount = accountService.updateAccount(account);
        return new ResponseEntity<>(updateAccount, HttpStatus.OK);
    }

    //deposit
    @PatchMapping("/{id}/deposit")
    public ResponseEntity<Account> depositeAccount(@PathVariable Long id,
                                                   @RequestBody Map<String,Double> req){
      
         if (!req.containsKey("amount")) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);  // Return bad request if amount is missing
        }
        double amount =req.get("amount");
        Account depositeAmount = accountService.deposite(id,amount);
        return new ResponseEntity<>(depositeAmount,HttpStatus.OK);
    }
   
    //withdraw
    @PatchMapping("/withdraw")
    public ResponseEntity<Account> withdrawAmount(@RequestParam Long id,
                                                   @RequestBody Map<String,Double> req){ 
        if (!req.containsKey("amount")) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);  // Return bad request if amount is missing
        }
        Double amount = req.get("amount");
        Account account = accountService.withdraw(id, amount);
        return new ResponseEntity<>(account,HttpStatus.OK);
    }

    //delete
    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteAccount(@RequestParam Long id){
        String res =accountService.deleteAccount(id);
        return  ResponseEntity.ok(res);
    }

    //get all accounts
    @GetMapping("/allAccounts")
    public ResponseEntity<List<Account>> getAllAccount(){
        
        List<Account> list = accountService.allAccount();
        return new  ResponseEntity<>(list,HttpStatus.OK);
    }
    

        
    
}
