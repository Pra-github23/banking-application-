package com.example.banking.service;

import org.springframework.stereotype.Service;

import com.example.banking.exception.AccountNotFoundException;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.banking.entity.Account;
import com.example.banking.repository.AccountRepository;

@Service
public class AccountServiceImp implements AccountService{
     
    @Autowired
    private AccountRepository accountRepository;
    

    @Override
    public Account createAccount(Account account) {
        
        return  accountRepository.save(account);
    }


    @Override
    public Account getAccount(Long id) {
        // Throw custom exception if account is not found
        return accountRepository.findById(id).orElseThrow(() -> 
               new AccountNotFoundException("Account with id " + id + " not found"));
    }


    @Override
    public Account updateAccount(Account account) {
       return accountRepository.save(account);
    }


    @Override
    public Account deposite(Long id, Double amount) {
         Account account = accountRepository.findById(id).orElseThrow(() -> 
                           new AccountNotFoundException("Account with id " + id + " not found"));
          
         Double totalAmount = account.getBalance() + amount;
         account.setBalance(totalAmount);
       return accountRepository.save(account);
    }


    @Override
    public Account withdraw(Long id, Double amount) {

       Account account = accountRepository.findById(id).orElseThrow(()->new  RuntimeException("Account Not Found"));
       double totalAmount = account.getBalance();

       if(totalAmount < amount) throw new RuntimeException("insufficient balance is "+ totalAmount);

       double updateAmount = totalAmount - amount;
       account.setBalance(updateAmount);
       return accountRepository.save(account);
    }


    @Override
    public String deleteAccount(Long id) {
       Account account = accountRepository.findById(id).orElseThrow(()-> new RuntimeException("Account Not Found"));
       accountRepository.deleteById(id);
       return "Account successfully deleted.";
    }


    @Override
    public List<Account> allAccount() {
        List<Account> list = accountRepository.findAll();
        return list;
    }

}
