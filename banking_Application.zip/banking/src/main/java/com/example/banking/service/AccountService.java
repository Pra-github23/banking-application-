package com.example.banking.service;

import java.util.List;

import com.example.banking.entity.Account;

public interface AccountService {

    Account createAccount(Account account);
    Account getAccount(Long id);
    Account updateAccount(Account account);
    Account deposite(Long id , Double amount);
    Account withdraw(Long id, Double amount);
    String deleteAccount(Long id);
    List<Account> allAccount();
}
