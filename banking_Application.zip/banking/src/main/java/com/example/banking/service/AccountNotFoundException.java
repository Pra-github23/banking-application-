package com.example.banking.service;

public class AccountNotFoundException {

}
